package javarobot.chapter6;

public enum FilterType 
{
	BLACK, WHITE, GREY, GREEN, RED, BLUE, ALPHA
}
